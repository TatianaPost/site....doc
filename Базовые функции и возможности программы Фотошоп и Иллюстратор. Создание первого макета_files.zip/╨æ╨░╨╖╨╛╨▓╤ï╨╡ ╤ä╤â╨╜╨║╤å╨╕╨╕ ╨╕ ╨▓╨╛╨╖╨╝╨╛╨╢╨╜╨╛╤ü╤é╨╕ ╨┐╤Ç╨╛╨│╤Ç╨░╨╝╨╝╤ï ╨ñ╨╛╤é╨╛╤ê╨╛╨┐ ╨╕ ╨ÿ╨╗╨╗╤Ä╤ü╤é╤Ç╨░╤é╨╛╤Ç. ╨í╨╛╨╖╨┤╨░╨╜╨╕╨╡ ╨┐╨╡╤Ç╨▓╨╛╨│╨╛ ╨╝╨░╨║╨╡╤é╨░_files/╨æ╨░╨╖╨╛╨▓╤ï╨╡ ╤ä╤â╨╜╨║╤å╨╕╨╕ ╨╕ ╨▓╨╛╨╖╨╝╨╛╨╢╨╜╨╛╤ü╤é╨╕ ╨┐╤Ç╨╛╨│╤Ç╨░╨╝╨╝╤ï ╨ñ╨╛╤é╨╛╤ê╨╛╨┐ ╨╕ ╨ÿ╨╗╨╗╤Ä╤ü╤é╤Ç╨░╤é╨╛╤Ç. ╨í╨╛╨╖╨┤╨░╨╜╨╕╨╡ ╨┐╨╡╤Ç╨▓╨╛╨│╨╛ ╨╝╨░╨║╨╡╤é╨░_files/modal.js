(function (w, d) {
    w.Modal = function (params) {
        if (params && params.title) {
            var content = typeof params.content !== "undefined" ? params.content : false,
                confirm_text = typeof params.confirmText !== "undefined" ? params.confirmText : "ОК",
                cancel_text = typeof params.cancelText !== "undefined" ? params.cancelText : "Отмена",
                confirm = typeof params.confirm !== "undefined" ? params.confirm : true;
            var shadow = d.createElement("div"),
                modal = d.createElement("div"),
                title = d.createElement("div"),
                confirm_btn = d.createElement("div");

            shadow.style.position = "fixed";
            shadow.style.top = 0;
            shadow.style.left = 0;
            shadow.style.width = "100vw";
            shadow.style.height = "100vh";
            shadow.style.textAlign = "center";
            shadow.style.background = "rgba(0, 0, 0, .5)";
            shadow.style["-webkit-overflow-scrolling"] =  "touch";
            shadow.style.overflow = "scroll";
            d.body.style.overflow = "hidden";
            d.body.appendChild(shadow);

            modal.style.background = "#fff";
            modal.style.padding = "20px";
            modal.style.display = "inline-block";
            modal.style.width = "500px";
            modal.style.maxWidth = "100%";
            shadow.appendChild(modal);

            title.innerHTML = params.title;
            title.style.color = "#6999cf";
            title.style.fontSize = "25px";
            title.style.fontWeight = "600";
            title.style.marginBottom = "30px";
            modal.appendChild(title);

            if (content) {
                var content_block = d.createElement("div");
                if (typeof content == "object") {
                    content_block.appendChild(content);
                } else {
                    content_block.innerHTML = content;
                }
                content_block.style.marginBottom = "30px";
                modal.appendChild(content_block);
            }

            if (confirm) {
                confirm_btn.className = "btn btn-green round";
                confirm_btn.innerHTML = confirm_text;
                confirm_btn.style.display = "inline-block";
                confirm_btn.style.margin = "0 30px";
                modal.appendChild(confirm_btn);

                confirm_btn.onclick = function () {
                    if (params.onConfirm) {
                        params.onConfirm();
                    }
                    d.body.style.display = "auto";
                    setTimeout(function(){
                        d.body.removeChild(shadow);
                    }, 100);
                };
            }

            if (params.cancel) {
                var cancel_btn = d.createElement("div");
                    cancel_btn.className = "btn btn-red round";
                    cancel_btn.innerHTML = cancel_text;
                    cancel_btn.style.display = "inline-block";
                    cancel_btn.style.margin = "0 30px";
                modal.appendChild(cancel_btn);

                cancel_btn.onclick = function(){
                    d.body.removeChild(shadow);
                    d.body.style.overflow = "auto";
                    if (params.onCancel) {
                        params.onCancel();
                    }
                };
            }

            if (modal.offsetHeight < shadow.offsetHeight) {
                modal.style.marginTop = (shadow.offsetHeight - modal.offsetHeight) / 2 + "px";
            }
        }
    }
})(window, document);
